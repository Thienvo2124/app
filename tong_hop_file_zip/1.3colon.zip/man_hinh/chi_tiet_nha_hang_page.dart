import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';

import '../mo_hinh/nha_hang.dart';
import '../tien_ich/dinh_dang.dart'; // nếu bạn muốn format ngày giờ nơi khác
import 'dat_ban_page.dart';
import 'tai_khoan_page.dart';

class ChiTietNhaHangPage extends StatelessWidget {
  final NhaHang nhaHang;
  const ChiTietNhaHangPage({super.key, required this.nhaHang});

  @override
  Widget build(BuildContext context) {
    final text = Theme.of(context).textTheme;

    return Scaffold(
      appBar: AppBar(title: Text(nhaHang.ten)),
      body: SafeArea(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            // Ảnh hero
            Hero(
              tag: 'nhahang_${nhaHang.id}',
              child: AspectRatio(
                aspectRatio: 16/9,
                child: Image.network(
                  nhaHang.anh,
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => Container(
                    color: Colors.grey.shade300,
                    alignment: Alignment.center,
                    child: const Icon(Icons.image_not_supported_outlined),
                  ),
                ),
              ),
            ),

            Padding(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(nhaHang.ten, style: text.titleLarge?.copyWith(fontWeight: FontWeight.w800)),
                  const SizedBox(height: 6),
                  Row(
                    children: [
                      Icon(Icons.place_outlined, size: 18, color: Colors.grey[700]),
                      const SizedBox(width: 6),
                      Expanded(child: Text(nhaHang.diaChi)),
                    ],
                  ),
                  const SizedBox(height: 6),
                  Row(
                    children: [
                      Chip(label: Text(nhaHang.thanhPho)),
                      const SizedBox(width: 8),
                      Chip(label: Text(nhaHang.amThuc)),
                    ],
                  ),
                  const SizedBox(height: 8),
                  _Stars(rating: nhaHang.danhGia),

                  const SizedBox(height: 16),
                  const Divider(height: 1),
                  const SizedBox(height: 12),

                  Text('Giới thiệu', style: text.titleMedium?.copyWith(fontWeight: FontWeight.w700)),
                  const SizedBox(height: 6),
                  Text(
                    nhaHang.moTa,
                    style: text.bodyMedium?.copyWith(height: 1.35),
                  ),

                  const SizedBox(height: 24),
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton.icon(
                      icon: const Icon(Icons.event_seat_outlined),
                      label: const Text('Đặt bàn'),
                      onPressed: () {
                        final user = FirebaseAuth.instance.currentUser;
                        if (user == null) {
                          // Chưa đăng nhập -> gợi ý đăng nhập
                          showDialog(
                            context: context,
                            builder: (_) => AlertDialog(
                              title: const Text('Yêu cầu đăng nhập'),
                              content: const Text('Bạn cần đăng nhập để đặt bàn.'),
                              actions: [
                                TextButton(
                                  onPressed: () => Navigator.pop(context),
                                  child: const Text('Đóng'),
                                ),
                                FilledButton(
                                  onPressed: () {
                                    Navigator.pop(context);
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(builder: (_) => const TaiKhoanPage()),
                                    );
                                  },
                                  child: const Text('Đăng nhập'),
                                ),
                              ],
                            ),
                          );
                          return;
                        }

                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (_) => DatBanPage(nhaHang: nhaHang)),
                        );
                      },
                    ),
                  ),

                  const SizedBox(height: 24),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _Stars extends StatelessWidget {
  final double rating;
  const _Stars({required this.rating});

  @override
  Widget build(BuildContext context) {
    final full = rating.floor();
    final half = (rating - full) >= 0.5;
    const total = 5;
    final icons = <Widget>[];

    for (int i = 0; i < full; i++) {
      icons.add(const Icon(Icons.star_rounded, color: Colors.amber, size: 20));
    }
    if (half) icons.add(const Icon(Icons.star_half_rounded, color: Colors.amber, size: 20));
    while (icons.length < total) {
      icons.add(const Icon(Icons.star_border_rounded, color: Colors.amber, size: 20));
    }

    return Row(children: icons.take(total).toList());
  }
}
