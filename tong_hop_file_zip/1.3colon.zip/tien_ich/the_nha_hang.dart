import 'package:flutter/material.dart';
import '../mo_hinh/nha_hang.dart';
import '../man_hinh/dat_ban_page.dart';
import '../man_hinh/tai_khoan_page.dart';
import '../dich_vu/xac_thuc.dart';

class TheNhaHang extends StatelessWidget {
  final NhaHang nhaHang;
  const TheNhaHang({super.key, required this.nhaHang});

  void _moDangNhap(BuildContext context) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: const Text('Yêu cầu đăng nhập'),
        action: SnackBarAction(
          label: 'Đăng nhập',
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => TaiKhoanPage(nhaHangMuonDat: nhaHang),
              ),
            );
          },
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      clipBehavior: Clip.antiAlias,
      elevation: 1,
      child: Row(
        children: [
          // Ảnh
          SizedBox(
            width: 120,
            height: 100,
            child: Image.network(
              nhaHang.anh,
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => const ColoredBox(
                color: Color(0xFFE0E0E0),
                child: Center(child: Icon(Icons.image_not_supported_outlined)),
              ),
            ),
          ),
          const SizedBox(width: 12),

          // Thông tin
          Expanded(
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 4),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(nhaHang.ten,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                          fontSize: 16, fontWeight: FontWeight.w700)),
                  const SizedBox(height: 4),
                  Row(
                    children: [
                      const Icon(Icons.location_on_outlined, size: 16),
                      const SizedBox(width: 4),
                      Expanded(
                        child: Text(
                          '${nhaHang.diaChi}, ${nhaHang.thanhPho}',
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Row(
                    children: [
                      const Icon(Icons.restaurant_menu, size: 16),
                      const SizedBox(width: 4),
                      Text(nhaHang.amThuc),
                      const SizedBox(width: 12),
                      const Icon(Icons.star_rate_rounded, size: 16),
                      Text(nhaHang.danhGia.toString()),
                    ],
                  ),
                ],
              ),
            ),
          ),

          // Nút Đặt bàn (bị khoá nếu chưa đăng nhập)
          Padding(
            padding: const EdgeInsets.only(right: 8),
            child: ValueListenableBuilder(
              valueListenable: AuthService.I.hienTai,
              builder: (context, user, _) {
                final loggedIn = user != null;
                return FilledButton.icon(
                  onPressed: () {
                    if (!loggedIn) {
                      _moDangNhap(context);
                      return;
                    }
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => DatBanPage(nhaHang: nhaHang),
                      ),
                    );
                  },
                  icon: const Icon(Icons.event_seat_outlined),
                  label: const Text('Đặt bàn'),
                  style: FilledButton.styleFrom(
                    // Nhìn “mờ” khi chưa đăng nhập
                    backgroundColor: loggedIn ? null : Colors.grey.shade400,
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
