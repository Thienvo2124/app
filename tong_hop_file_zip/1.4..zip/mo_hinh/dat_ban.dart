// lib/mo_hinh/dat_ban.dart
class DatBan {
  final String tenKhachHang;
  final String sdt;
  final DateTime thoiGian;
  final String nhaHang;

  DatBan({
    required this.tenKhachHang,
    required this.sdt,
    required this.thoiGian,
    required this.nhaHang,
  });
}
