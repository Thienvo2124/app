class NguoiDung {
  final String email;
  final String ten;
  const NguoiDung({required this.email, required this.ten});
}
