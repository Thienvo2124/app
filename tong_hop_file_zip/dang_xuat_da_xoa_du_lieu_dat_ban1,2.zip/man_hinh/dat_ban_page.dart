import 'dart:math';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:firebase_auth/firebase_auth.dart';

import '../mo_hinh/nha_hang.dart';
import '../mo_hinh/don_dat_ban.dart';
import 'thanh_cong_page.dart';

class DatBanPage extends StatefulWidget {
  final NhaHang nhaHang;
  const DatBanPage({super.key, required this.nhaHang});

  @override
  State<DatBanPage> createState() => _DatBanPageState();
}

class _DatBanPageState extends State<DatBanPage> {
  final _formKey = GlobalKey<FormState>();
  final tenController = TextEditingController();
  final sdtController = TextEditingController();
  final ghiChuController = TextEditingController();

  DateTime? _ngay;
  TimeOfDay? _gio;
  int _soNguoi = 2;
  bool _dangLuu = false;

  bool get _isReady =>
      tenController.text.trim().isNotEmpty &&
          sdtController.text.trim().length >= 8 &&
          _ngay != null &&
          _gio != null;

  @override
  void initState() {
    super.initState();
    tenController.addListener(() => setState(() {}));
    sdtController.addListener(() => setState(() {}));
  }

  @override
  void dispose() {
    tenController.dispose();
    sdtController.dispose();
    ghiChuController.dispose();
    super.dispose();
  }

  // ---- KEY theo user (UID) hoặc guest
  String get _storageKey {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    return uid == null ? 'don_dat_ban_local_guest' : 'don_dat_ban_local_$uid';
  }

  Future<void> _chonNgay() async {
    final now = DateTime.now();
    final picked = await showDatePicker(
      context: context,
      initialDate: _ngay ?? now,
      firstDate: DateTime(now.year, now.month, now.day),
      lastDate: now.add(const Duration(days: 365)),
    );
    if (picked != null) setState(() => _ngay = picked);
  }

  Future<void> _chonGio() async {
    final picked = await showTimePicker(
      context: context,
      initialTime: _gio ?? const TimeOfDay(hour: 18, minute: 0),
    );
    if (picked != null) setState(() => _gio = picked);
  }

  Future<void> _luuLocal(DonDatBan d) async {
    final sp = await SharedPreferences.getInstance();
    final list = sp.getStringList(_storageKey) ?? <String>[];
    list.insert(0, d.toJson()); // mới nhất lên đầu
    await sp.setStringList(_storageKey, list);
  }

  String _randomId() {
    const chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
    final r = Random();
    return List.generate(20, (_) => chars[r.nextInt(chars.length)]).join();
  }

  Future<void> _xacNhan() async {
    if (!_formKey.currentState!.validate()) return;
    if (_ngay == null || _gio == null) {
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('Bạn chưa chọn ngày/giờ.')));
      return;
    }

    final thoiGian = DateTime(
      _ngay!.year, _ngay!.month, _ngay!.day, _gio!.hour, _gio!.minute,
    );

    setState(() => _dangLuu = true);
    try {
      final don = DonDatBan(
        id: _randomId(),
        nhaHangId: widget.nhaHang.id,
        nhaHangTen: widget.nhaHang.ten,
        diaDiem: widget.nhaHang.thanhPho,
        tenKhachHang: tenController.text.trim(),
        sdt: sdtController.text.trim(),
        soNguoi: _soNguoi,
        thoiGian: thoiGian,
        ghiChu: ghiChuController.text.trim(),
      );
      await _luuLocal(don);

      if (!mounted) return;
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (_) => ThanhCongPage(
            tieuDe: 'Đặt bàn thành công',
            moTa:
            'Hẹn bạn tại ${widget.nhaHang.ten} lúc '
                '${_gio!.format(context)} ngày '
                '${_ngay!.day}/${_ngay!.month}/${_ngay!.year}.',
          ),
        ),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('Lỗi đặt bàn: $e')));
    } finally {
      if (mounted) setState(() => _dangLuu = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final ngayText =
    _ngay == null ? 'Chọn ngày' : '${_ngay!.day}/${_ngay!.month}/${_ngay!.year}';
    final gioText = _gio == null ? 'Chọn giờ' : _gio!.format(context);

    return Scaffold(
      appBar: AppBar(title: Text('Đặt bàn - ${widget.nhaHang.ten}')),
      body: SafeArea(
        child: Form(
          key: _formKey,
          autovalidateMode: AutovalidateMode.onUserInteraction,
          child: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              TextFormField(
                controller: tenController,
                decoration: const InputDecoration(
                  labelText: 'Tên khách hàng',
                  prefixIcon: Icon(Icons.person_outline),
                ),
                validator: (v) =>
                (v == null || v.trim().isEmpty) ? 'Vui lòng nhập tên' : null,
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: sdtController,
                keyboardType: TextInputType.phone,
                decoration: const InputDecoration(
                  labelText: 'Số điện thoại',
                  prefixIcon: Icon(Icons.phone_outlined),
                ),
                validator: (v) =>
                (v == null || v.trim().length < 8) ? 'SĐT không hợp lệ' : null,
              ),
              const SizedBox(height: 12),

              Row(
                children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: _chonNgay,
                      icon: const Icon(Icons.calendar_today_outlined),
                      label: Text(ngayText),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: _chonGio,
                      icon: const Icon(Icons.schedule_outlined),
                      label: Text(gioText),
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 12),
              Row(
                children: [
                  const Text('Số người:'),
                  const SizedBox(width: 12),
                  DropdownButton<int>(
                    value: _soNguoi,
                    items: List.generate(10, (i) => i + 1)
                        .map((e) => DropdownMenuItem(value: e, child: Text('$e')))
                        .toList(),
                    onChanged: (v) => setState(() => _soNguoi = v ?? 2),
                  ),
                ],
              ),

              const SizedBox(height: 12),
              TextField(
                controller: ghiChuController,
                maxLines: 3,
                decoration: const InputDecoration(
                  labelText: 'Ghi chú (tuỳ chọn)',
                  prefixIcon: Icon(Icons.notes_outlined),
                ),
              ),

              const SizedBox(height: 20),
              FilledButton.icon(
                onPressed: (_dangLuu || !_isReady) ? null : _xacNhan,
                icon: _dangLuu
                    ? const SizedBox(
                  width: 18, height: 18,
                  child: CircularProgressIndicator(strokeWidth: 2),
                )
                    : const Icon(Icons.check_circle_outline),
                label: Text(_dangLuu ? 'Đang lưu...' : 'Xác nhận đặt bàn'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
