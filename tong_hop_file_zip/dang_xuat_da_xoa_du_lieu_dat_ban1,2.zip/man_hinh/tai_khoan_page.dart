import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';

import '../mo_hinh/nha_hang.dart';
import 'dat_ban_page.dart';

class TaiKhoanPage extends StatelessWidget {
  /// Nếu truyền nhà hàng vào, sau khi đăng nhập xong sẽ tự chuyển sang DatBanPage
  final NhaHang? nhaHangMuonDat;

  const TaiKhoanPage({super.key, this.nhaHangMuonDat});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(
      stream: FirebaseAuth.instance.authStateChanges(),
      builder: (context, snap) {
        final user = snap.data;

        if (snap.connectionState == ConnectionState.waiting) {
          return const Scaffold(body: Center(child: CircularProgressIndicator()));
        }

        // Đã đăng nhập
        if (user != null) {
          // Nếu có yêu cầu redirect sang đặt bàn, điều hướng và dừng build
          if (nhaHangMuonDat != null) {
            // Điều hướng sau 1 frame để không lỗi setState during build
            WidgetsBinding.instance.addPostFrameCallback((_) {
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(
                  builder: (_) => DatBanPage(nhaHang: nhaHangMuonDat!),
                ),
              );
            });
            return const Scaffold(
              body: Center(child: CircularProgressIndicator()),
            );
          }

          // Không cần redirect -> hiện trang thông tin tài khoản
          return _ProfileScreen(user: user);
        }

        // Chưa đăng nhập -> hiện form
        return const _AuthScreen();
      },
    );
  }
}

/* ---------------------- AUTH: Login / Register ---------------------- */

class _AuthScreen extends StatefulWidget {
  const _AuthScreen();

  @override
  State<_AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<_AuthScreen>
    with SingleTickerProviderStateMixin {
  final _loginEmail = TextEditingController();
  final _loginPass = TextEditingController();
  final _regEmail = TextEditingController();
  final _regPass = TextEditingController();

  final _loginKey = GlobalKey<FormState>();
  final _regKey = GlobalKey<FormState>();

  bool _busy = false;
  late final TabController _tab = TabController(length: 2, vsync: this);

  @override
  void dispose() {
    _loginEmail.dispose();
    _loginPass.dispose();
    _regEmail.dispose();
    _regPass.dispose();
    _tab.dispose();
    super.dispose();
  }

  Future<void> _dangNhap() async {
    if (!_loginKey.currentState!.validate()) return;
    setState(() => _busy = true);
    try {
      await FirebaseAuth.instance.signInWithEmailAndPassword(
        email: _loginEmail.text.trim(),
        password: _loginPass.text,
      );
      _loginEmail.clear();
      _loginPass.clear();
      // StreamBuilder ở trên sẽ tự rebuild
    } on FirebaseAuthException catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(e.message ?? 'Đăng nhập thất bại')),
      );
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _dangKy() async {
    if (!_regKey.currentState!.validate()) return;
    setState(() => _busy = true);
    try {
      await FirebaseAuth.instance.createUserWithEmailAndPassword(
        email: _regEmail.text.trim(),
        password: _regPass.text,
      );
      _regEmail.clear();
      _regPass.clear();
      _tab.animateTo(0);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Đăng ký thành công. Hãy đăng nhập!')),
      );
    } on FirebaseAuthException catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(e.message ?? 'Đăng ký thất bại')),
      );
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  String? _validateEmail(String? v) {
    final s = v?.trim() ?? '';
    if (s.isEmpty || !s.contains('@')) return 'Email không hợp lệ';
    return null;
  }

  String? _validatePass(String? v) =>
      (v == null || v.length < 6) ? 'Mật khẩu >= 6 ký tự' : null;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Tài khoản'),
        bottom: TabBar(
          controller: _tab,
          tabs: const [Tab(text: 'Đăng nhập'), Tab(text: 'Đăng ký')],
        ),
      ),
      body: TabBarView(
        controller: _tab,
        children: [
          // ---- Đăng nhập
          Padding(
            padding: const EdgeInsets.all(16),
            child: Form(
              key: _loginKey,
              child: Column(
                children: [
                  TextFormField(
                    controller: _loginEmail,
                    keyboardType: TextInputType.emailAddress,
                    decoration: const InputDecoration(
                      labelText: 'Email (@gmail.com)',
                      prefixIcon: Icon(Icons.email_outlined),
                    ),
                    validator: _validateEmail,
                  ),
                  const SizedBox(height: 12),
                  TextFormField(
                    controller: _loginPass,
                    obscureText: true,
                    decoration: const InputDecoration(
                      labelText: 'Mật khẩu',
                      prefixIcon: Icon(Icons.lock_outline),
                    ),
                    validator: _validatePass,
                  ),
                  const Spacer(),
                  FilledButton(
                    onPressed: _busy ? null : _dangNhap,
                    child: _busy
                        ? const SizedBox(
                      width: 18, height: 18,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                        : const Text('Đăng nhập'),
                  ),
                  const SizedBox(height: 16),
                ],
              ),
            ),
          ),
          // ---- Đăng ký
          Padding(
            padding: const EdgeInsets.all(16),
            child: Form(
              key: _regKey,
              child: Column(
                children: [
                  TextFormField(
                    controller: _regEmail,
                    keyboardType: TextInputType.emailAddress,
                    decoration: const InputDecoration(
                      labelText: 'Email (@gmail.com)',
                      prefixIcon: Icon(Icons.email_outlined),
                    ),
                    validator: _validateEmail,
                  ),
                  const SizedBox(height: 12),
                  TextFormField(
                    controller: _regPass,
                    obscureText: true,
                    decoration: const InputDecoration(
                      labelText: 'Mật khẩu (>= 6 ký tự)',
                      prefixIcon: Icon(Icons.lock_outline),
                    ),
                    validator: _validatePass,
                  ),
                  const Spacer(),
                  FilledButton.tonal(
                    onPressed: _busy ? null : _dangKy,
                    child: _busy
                        ? const SizedBox(
                      width: 18, height: 18,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                        : const Text('Đăng ký'),
                  ),
                  const SizedBox(height: 16),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

/* --------------------------- PROFILE (Đã login) --------------------------- */

class _ProfileScreen extends StatelessWidget {
  final User user;
  const _ProfileScreen({required this.user});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Tài khoản')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          ListTile(
            leading: const CircleAvatar(child: Icon(Icons.person)),
            title: Text(user.email ?? '(không có email)'),
            subtitle: Text('UID: ${user.uid}'),
          ),
          const SizedBox(height: 8),
          FilledButton.icon(
            onPressed: () async {
              await FirebaseAuth.instance.signOut();
            },
            icon: const Icon(Icons.logout),
            label: const Text('Đăng xuất'),
          ),
        ],
      ),
    );
  }
}
