import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/foundation.dart';

/// Dịch vụ xác thực dùng FirebaseAuth
class AuthService {
  AuthService._();
  static final AuthService I = AuthService._();

  final FirebaseAuth _fa = FirebaseAuth.instance;

  /// Người dùng hiện tại (listen để UI tự đổi trạng thái)
  final ValueNotifier<User?> hienTai = ValueNotifier<User?>(null);

  /// Gọi 1 lần ở main() để lắng nghe trạng thái đăng nhập
  void khoiDong() {
    hienTai.value = _fa.currentUser;
    _fa.authStateChanges().listen((u) {
      hienTai.value = u;
    });
  }

  /// Đăng ký — trả về chuỗi lỗi nếu có, null nếu OK
  Future<String?> dangKy({
    required String email,
    required String matKhau,
    String? ten,
  }) async {
    try {
      final cred = await _fa.createUserWithEmailAndPassword(
        email: email,
        password: matKhau,
      );
      if (ten != null && ten.trim().isNotEmpty) {
        await cred.user?.updateDisplayName(ten.trim());
        await cred.user?.reload();
        hienTai.value = _fa.currentUser;
      }
      return null;
    } on FirebaseAuthException catch (e) {
      return _mapLoi(e);
    } catch (e) {
      return 'Có lỗi xảy ra. Vui lòng thử lại.';
    }
  }

  /// Đăng nhập — trả về chuỗi lỗi nếu có, null nếu OK
  Future<String?> dangNhap({
    required String email,
    required String matKhau,
  }) async {
    try {
      await _fa.signInWithEmailAndPassword(email: email, password: matKhau);
      return null;
    } on FirebaseAuthException catch (e) {
      return _mapLoi(e);
    } catch (e) {
      return 'Có lỗi xảy ra. Vui lòng thử lại.';
    }
  }

  Future<void> dangXuat() async {
    await _fa.signOut();
  }

  String _mapLoi(FirebaseAuthException e) {
    switch (e.code) {
      case 'email-already-in-use':
        return 'Email này đã được sử dụng.';
      case 'invalid-email':
        return 'Email không hợp lệ.';
      case 'weak-password':
        return 'Mật khẩu quá yếu.';
      case 'user-not-found':
      case 'wrong-password':
        return 'Email hoặc mật khẩu không đúng.';
      case 'user-disabled':
        return 'Tài khoản đã bị vô hiệu hóa.';
      default:
        return 'Lỗi: ${e.message ?? e.code}';
    }
  }
}
