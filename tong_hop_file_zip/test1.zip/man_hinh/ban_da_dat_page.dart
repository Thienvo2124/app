// lib/man_hinh/ban_da_dat_page.dart
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class BanDaDatPage extends StatelessWidget {
  const BanDaDatPage({super.key});

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;

    // Chưa đăng nhập
    if (user == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('Bàn đã đặt')),
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.event_seat_outlined, size: 72),
                const SizedBox(height: 12),
                const Text(
                  'Bạn cần đăng nhập để xem các bàn đã đặt.',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 16),
                ),
                const SizedBox(height: 16),
                FilledButton(
                  onPressed: () {
                    // TODO: điều hướng sang trang tài khoản/đăng nhập của bạn
                    // Navigator.push(context, MaterialPageRoute(builder: (_) => const TaiKhoanPage()));
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Đi tới mục Tài khoản để đăng nhập.')),
                    );
                  },
                  child: const Text('Đến trang Tài khoản'),
                ),
              ],
            ),
          ),
        ),
      );
    }

    // Đã đăng nhập: stream đơn đặt bàn theo uid
    final q = FirebaseFirestore.instance
        .collection('don_dat_ban')
        .where('uid', isEqualTo: user.uid)
        .orderBy('created_at', descending: true);

    return Scaffold(
      appBar: AppBar(title: const Text('Bàn đã đặt')),
      body: StreamBuilder<QuerySnapshot>(
        stream: q.snapshots(),
        builder: (context, snap) {
          if (snap.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snap.hasError) {
            return Center(child: Text('Lỗi tải dữ liệu: ${snap.error}'));
          }

          final docs = snap.data?.docs ?? [];
          if (docs.isEmpty) {
            return const _EmptyState();
          }

          return ListView.separated(
            padding: const EdgeInsets.all(12),
            itemCount: docs.length,
            separatorBuilder: (_, __) => const SizedBox(height: 8),
            itemBuilder: (context, i) {
              final d = docs[i].data() as Map<String, dynamic>;
              final tenNhaHang = (d['nha_hang_ten'] ?? '') as String;
              final diaDiem = (d['nha_hang_thanh_pho'] ?? '') as String;
              final thoiGianTs = d['thoi_gian'];
              DateTime? thoiGian;
              if (thoiGianTs is Timestamp) thoiGian = thoiGianTs.toDate();
              final soNguoi = (d['so_nguoi'] ?? 0) as int;
              final tenKH = (d['ten_khach_hang'] ?? '') as String;
              final sdt = (d['so_dien_thoai'] ?? '') as String;
              final ghiChu = (d['ghi_chu'] ?? '') as String;

              return _BookingCard(
                tenNhaHang: tenNhaHang,
                diaDiem: diaDiem,
                thoiGian: thoiGian,
                soNguoi: soNguoi,
                tenKhachHang: tenKH,
                sdt: sdt,
                ghiChu: ghiChu,
              );
            },
          );
        },
      ),
    );
  }
}

class _EmptyState extends StatelessWidget {
  const _EmptyState();

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: const [
            Icon(Icons.playlist_remove, size: 72, color: Colors.black45),
            SizedBox(height: 12),
            Text(
              'Chưa có bàn nào được đặt.',
              style: TextStyle(fontSize: 16, color: Colors.black87),
            ),
            SizedBox(height: 4),
            Text(
              'Hãy vào Trang chủ để đặt bàn nhé!',
              style: TextStyle(fontSize: 14, color: Colors.black54),
            ),
          ],
        ),
      ),
    );
  }
}

class _BookingCard extends StatelessWidget {
  final String tenNhaHang;
  final String diaDiem;
  final DateTime? thoiGian;
  final int soNguoi;
  final String tenKhachHang;
  final String sdt;
  final String ghiChu;

  const _BookingCard({
    required this.tenNhaHang,
    required this.diaDiem,
    required this.thoiGian,
    required this.soNguoi,
    required this.tenKhachHang,
    required this.sdt,
    required this.ghiChu,
  });

  @override
  Widget build(BuildContext context) {
    final tg = thoiGian;
    final timeStr = (tg == null)
        ? '—'
        : '${tg.hour.toString().padLeft(2, '0')}:${tg.minute.toString().padLeft(2, '0')} '
        '${tg.day.toString().padLeft(2, '0')}/${tg.month.toString().padLeft(2, '0')}/${tg.year}';

    return Card(
      elevation: 0,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Tiêu đề
            Row(
              children: [
                const Icon(Icons.restaurant_menu, size: 20),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    tenNhaHang,
                    style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 6),

            // Dòng địa điểm + thời gian
            Row(
              children: [
                const Icon(Icons.place_outlined, size: 16),
                const SizedBox(width: 4),
                Expanded(
                  child: Text(
                    diaDiem,
                    style: const TextStyle(color: Colors.black54),
                  ),
                ),
                const SizedBox(width: 8),
                const Icon(Icons.schedule_outlined, size: 16),
                const SizedBox(width: 4),
                Text(timeStr, style: const TextStyle(color: Colors.black54)),
              ],
            ),
            const SizedBox(height: 8),

            // Dòng số người
            Row(
              children: [
                const Icon(Icons.groups_2_outlined, size: 16),
                const SizedBox(width: 4),
                Text('$soNguoi người', style: const TextStyle(color: Colors.black87)),
              ],
            ),
            const SizedBox(height: 8),

            // Thông tin KH
            Row(
              children: [
                const Icon(Icons.person_outline, size: 16),
                const SizedBox(width: 4),
                Expanded(child: Text(tenKhachHang)),
                const SizedBox(width: 8),
                const Icon(Icons.phone_outlined, size: 16),
                const SizedBox(width: 4),
                Text(sdt),
              ],
            ),

            if (ghiChu.isNotEmpty) ...[
              const SizedBox(height: 8),
              Text('Ghi chú: $ghiChu', style: const TextStyle(color: Colors.black87)),
            ],
          ],
        ),
      ),
    );
  }
}
