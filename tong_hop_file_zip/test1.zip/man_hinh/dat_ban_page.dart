import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

import '../mo_hinh/nha_hang.dart';
import 'thanh_cong_page.dart';

class DatBanPage extends StatefulWidget {
  static const routeName = '/dat-ban';
  final NhaHang nhaHang;
  const DatBanPage({super.key, required this.nhaHang});

  @override
  State<DatBanPage> createState() => _DatBanPageState();
}

class _DatBanPageState extends State<DatBanPage> {
  final tenController = TextEditingController();
  final sdtController = TextEditingController();
  final ghiChuController = TextEditingController();
  DateTime? _ngay;
  TimeOfDay? _gio;
  int soNguoi = 2;

  bool _dangLuu = false;

  @override
  void dispose() {
    tenController.dispose();
    sdtController.dispose();
    ghiChuController.dispose();
    super.dispose();
  }

  Future<void> _chonNgay() async {
    final now = DateTime.now();
    final picked = await showDatePicker(
      context: context,
      firstDate: now,
      lastDate: now.add(const Duration(days: 180)),
      initialDate: _ngay ?? now,
      locale: const Locale('vi'),
    );
    if (picked != null) setState(() => _ngay = picked);
  }

  Future<void> _chonGio() async {
    final picked = await showTimePicker(
      context: context,
      initialTime: _gio ?? TimeOfDay.now(),
    );
    if (picked != null) setState(() => _gio = picked);
  }

  String _hienNgay() {
    if (_ngay == null) return 'Chọn ngày';
    final d = _ngay!;
    return '${d.day.toString().padLeft(2, '0')}/${d.month.toString().padLeft(2, '0')}/${d.year}';
  }

  String _hienGio() {
    if (_gio == null) return 'Chọn giờ';
    final g = _gio!;
    return '${g.hour.toString().padLeft(2, '0')}:${g.minute.toString().padLeft(2, '0')}';
  }

  Future<void> _luu() async {
    if (tenController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Vui lòng nhập tên khách hàng')),
      );
      return;
    }
    if (sdtController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Vui lòng nhập số điện thoại')),
      );
      return;
    }
    if (_ngay == null || _gio == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Vui lòng chọn ngày và giờ')),
      );
      return;
    }

    final user = FirebaseAuth.instance.currentUser;
    if (user == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Yêu cầu đăng nhập')),
      );
      return;
    }

    final thoiGian = DateTime(
      _ngay!.year, _ngay!.month, _ngay!.day, _gio!.hour, _gio!.minute,
    );

    setState(() => _dangLuu = true);

    try {
      // Ghi Firestore
      await FirebaseFirestore.instance.collection('don_dat_ban').add({
        'uid': user.uid,
        'email': user.email?.toLowerCase(),
        'ten_khach_hang': tenController.text.trim(),
        'so_dien_thoai': sdtController.text.trim(),
        'nha_hang': widget.nhaHang.ten,
        'thoi_gian': Timestamp.fromDate(thoiGian),
        'so_nguoi': soNguoi,
        'ghi_chu': ghiChuController.text.trim(),
        'trang_thai': 'Chờ xác nhận',
        'created_at': FieldValue.serverTimestamp(),
      });

      if (!mounted) return;

      // Điều hướng trang thành công
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (_) => ThanhCongPage(
            tenKhachHang: tenController.text.trim(),
            sdt: sdtController.text.trim(),
            thoiGian: thoiGian,
            nhaHang: widget.nhaHang.ten,
          ),
        ),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Không thể gửi đơn: $e')),
      );
    } finally {
      if (mounted) setState(() => _dangLuu = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Đặt bàn - ${widget.nhaHang.ten}')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            TextField(
              controller: tenController,
              decoration: const InputDecoration(
                labelText: 'Tên khách hàng',
                prefixIcon: Icon(Icons.person_outline),
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: sdtController,
              decoration: const InputDecoration(
                labelText: 'Số điện thoại',
                prefixIcon: Icon(Icons.phone_outlined),
              ),
              keyboardType: TextInputType.phone,
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: ListTile(
                    leading: const Icon(Icons.calendar_today_outlined),
                    title: Text(_hienNgay()),
                    onTap: _chonNgay,
                    shape: RoundedRectangleBorder(
                      side: BorderSide(color: Theme.of(context).dividerColor),
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: ListTile(
                    leading: const Icon(Icons.schedule_outlined),
                    title: Text(_hienGio()),
                    onTap: _chonGio,
                    shape: RoundedRectangleBorder(
                      side: BorderSide(color: Theme.of(context).dividerColor),
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                const Text('Số người:'),
                const SizedBox(width: 12),
                DropdownButton<int>(
                  value: soNguoi,
                  items: List.generate(15, (i) => i + 1)
                      .map((v) => DropdownMenuItem(value: v, child: Text('$v')))
                      .toList(),
                  onChanged: (v) => setState(() => soNguoi = v ?? 2),
                ),
              ],
            ),
            const SizedBox(height: 12),
            TextField(
              controller: ghiChuController,
              decoration: const InputDecoration(
                labelText: 'Ghi chú (tuỳ chọn)',
                prefixIcon: Icon(Icons.note_outlined),
              ),
              maxLines: 3,
            ),
            const SizedBox(height: 20),
            SizedBox(
              width: double.infinity,
              child: FilledButton.icon(
                onPressed: _dangLuu ? null : _luu,
                icon: _dangLuu
                    ? const SizedBox(
                  width: 18, height: 18,
                  child: CircularProgressIndicator(strokeWidth: 2),
                )
                    : const Icon(Icons.check_circle),
                label: Text(_dangLuu ? 'Đang gửi...' : 'Xác nhận đặt bàn'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
