import 'package:flutter/material.dart';
import '../dich_vu/xac_thuc.dart';

class TaiKhoanPage extends StatelessWidget {
  final Object? nhaHangMuonDat;
  const TaiKhoanPage({super.key, this.nhaHangMuonDat});

  @override
  Widget build(BuildContext context) {
    // Controllers form Đăng nhập
    final emailDN = TextEditingController();
    final mkDN = TextEditingController();

    // Controllers form Đăng ký
    final emailDK = TextEditingController();
    final mkDK = TextEditingController();

    return ValueListenableBuilder(
      valueListenable: AuthService.I.hienTai,
      builder: (context, user, _) {
        // ĐÃ ĐĂNG NHẬP
        if (user != null) {
          return Scaffold(
            appBar: AppBar(title: const Text('Tài khoản')),
            body: SafeArea(
              child: Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.verified_user, size: 72),
                    const SizedBox(height: 12),
                    Text(
                      'Đăng nhập bằng:\n${user.email ?? '(không có email)'}',
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 16),
                    FilledButton.icon(
                      icon: const Icon(Icons.logout),
                      label: const Text('Đăng xuất'),
                      onPressed: () async {
                        await AuthService.I.dangXuat();
                        if (!context.mounted) return;
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('Đã đăng xuất')),
                        );
                      },
                    ),
                  ],
                ),
              ),
            ),
          );
        }

        // CHƯA ĐĂNG NHẬP: Tab Đăng nhập / Đăng ký
        return DefaultTabController(
          length: 2,
          child: Scaffold(
            appBar: AppBar(
              title: const Text('Tài khoản'),
              bottom: const TabBar(
                tabs: [
                  Tab(text: 'Đăng nhập'),
                  Tab(text: 'Đăng ký'),
                ],
              ),
            ),
            body: SafeArea(
              child: TabBarView(
                children: [
                  // ====== TAB ĐĂNG NHẬP ======
                  Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      children: [
                        TextField(
                          controller: emailDN,
                          decoration: const InputDecoration(
                            labelText: 'Email (@gmail.com)',
                            prefixIcon: Icon(Icons.email_outlined),
                          ),
                          keyboardType: TextInputType.emailAddress,
                        ),
                        const SizedBox(height: 12),
                        TextField(
                          controller: mkDN,
                          decoration: const InputDecoration(
                            labelText: 'Mật khẩu',
                            prefixIcon: Icon(Icons.lock_outline),
                          ),
                          obscureText: true,
                        ),
                        const Spacer(),
                        SizedBox(
                          width: double.infinity,
                          child: FilledButton(
                            onPressed: () async {
                              final email = emailDN.text.trim().toLowerCase();
                              if (!email.endsWith('@gmail.com')) {
                                ScaffoldMessenger.of(context).showSnackBar(
                                  const SnackBar(
                                    content: Text('Chỉ chấp nhận email @gmail.com'),
                                  ),
                                );
                                return;
                              }
                              final err = await AuthService.I.dangNhap(
                                email: email,
                                matKhau: mkDN.text,
                              );
                              if (err != null) {
                                if (!context.mounted) return;
                                ScaffoldMessenger.of(context)
                                    .showSnackBar(SnackBar(content: Text(err)));
                              } else {
                                if (!context.mounted) return;
                                ScaffoldMessenger.of(context).showSnackBar(
                                  const SnackBar(content: Text('Đăng nhập thành công')),
                                );
                              }
                            },
                            child: const Text('Đăng nhập'),
                          ),
                        ),
                      ],
                    ),
                  ),

                  // ====== TAB ĐĂNG KÝ ======
                  Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      children: [
                        TextField(
                          controller: emailDK,
                          decoration: const InputDecoration(
                            labelText: 'Email (@gmail.com)',
                            prefixIcon: Icon(Icons.alternate_email),
                          ),
                          keyboardType: TextInputType.emailAddress,
                        ),
                        const SizedBox(height: 12),
                        TextField(
                          controller: mkDK,
                          decoration: const InputDecoration(
                            labelText: 'Mật khẩu',
                            prefixIcon: Icon(Icons.lock_outline),
                          ),
                          obscureText: true,
                        ),
                        const SizedBox(height: 16),
                        SizedBox(
                          width: double.infinity,
                          child: FilledButton(
                            onPressed: () async {
                              final email = emailDK.text.trim().toLowerCase();
                              if (!email.endsWith('@gmail.com')) {
                                ScaffoldMessenger.of(context).showSnackBar(
                                  const SnackBar(
                                    content: Text('Chỉ chấp nhận email @gmail.com'),
                                  ),
                                );
                                return;
                              }
                              final err = await AuthService.I.dangKy(
                                email: email,
                                matKhau: mkDK.text,
                              );
                              if (err != null) {
                                if (!context.mounted) return;
                                ScaffoldMessenger.of(context)
                                    .showSnackBar(SnackBar(content: Text(err)));
                              } else {
                                if (!context.mounted) return;

                                // Làm sạch form
                                emailDK.clear();
                                mkDK.clear();
                                FocusScope.of(context).unfocus();

                                // Thông báo & chuyển sang tab Đăng nhập
                                ScaffoldMessenger.of(context).showSnackBar(
                                  const SnackBar(
                                    content: Text('Tài khoản đã tạo, vui lòng đăng nhập'),
                                  ),
                                );
                                DefaultTabController.of(context)?.animateTo(0);
                              }
                            },
                            child: const Text('Đăng ký'),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
