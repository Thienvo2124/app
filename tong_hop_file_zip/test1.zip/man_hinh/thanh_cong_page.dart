import 'package:flutter/material.dart';
import '../mo_hinh/dat_ban.dart';

class ThanhCongPage extends StatelessWidget {
  static const routeName = '/thanh-cong';

  final String tenKhachHang;
  final String sdt;
  final String nhaHang;
  final DateTime thoiGian;

  const ThanhCongPage({
    super.key,
    required this.tenKhachHang,
    required this.sdt,
    required this.nhaHang,
    required this.thoiGian,
  });

  /// Nếu bạn vẫn có DatBan, có thể dùng:
  factory ThanhCongPage.fromBooking(DatBan b) => ThanhCongPage(
    tenKhachHang: b.tenKhachHang,
    sdt: b.sdt,
    nhaHang: b.nhaHang,
    thoiGian: b.thoiGian,
  );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Đặt bàn thành công')),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Center(
              child: Icon(Icons.check_circle_rounded, color: Colors.teal, size: 100),
            ),
            const SizedBox(height: 20),
            Text(
              'Cảm ơn $tenKhachHang!',
              style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            Text('Nhà hàng: $nhaHang', style: const TextStyle(fontSize: 16)),
            Text(
              'Thời gian: ${thoiGian.day}/${thoiGian.month}/${thoiGian.year}',
              style: const TextStyle(fontSize: 16),
            ),
            const Spacer(),
            SizedBox(
              width: double.infinity,
              child: FilledButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('Về trang chủ'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
